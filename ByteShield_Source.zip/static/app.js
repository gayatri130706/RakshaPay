/**
 * ByteShield — Frontend Application Controller & Audio Synthesis Engine
 * Orchestrates real-time API transactions, Pre-PIN interception modals,
 * Multi-lingual Web Speech API regional alerts, and anti-coercion CAPTCHA.
 */

// Global State
let currentScenarios = [];
let currentAnalysisResult = null;
let currentVoiceLang = "en";
let isSpeaking = false;
let currentEnteredPin = "";
let isCoercedSelection = null;

// Sound Effects via Web Audio API
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playAlertTone(type = "warning") {
    try {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        if (type === "critical") {
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
            osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.3);
            gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.35);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.35);
        } else if (type === "click") {
            osc.type = "sine";
            osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
            gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.08);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.08);
        } else if (type === "success") {
            osc.type = "sine";
            osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
            osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.1); // A5
            gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.3);
        }
    } catch (e) {
        console.warn("AudioContext error:", e);
    }
}

// Initialization on DOM Load
document.addEventListener("DOMContentLoaded", () => {
    initClock();
    initTabs();
    initScenarios();
    bindFormEvents();
    bindModalEvents();
    bindPinpadEvents();
    bindThreatFeedEvents();
});

// Live Phone Clock
function initClock() {
    const clock = document.getElementById("phone-clock");
    const updateTime = () => {
        const d = new Date();
        if (clock) {
            clock.textContent = d.toTimeString().slice(0, 5);
        }
    };
    updateTime();
    setInterval(updateTime, 10000);
}

// Tab Switching
function initTabs() {
    const tabs = document.querySelectorAll(".nav-tab");
    const panels = document.querySelectorAll(".tab-panel");

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            panels.forEach(p => p.classList.remove("active"));

            tab.classList.add("active");
            const target = tab.dataset.tab;
            const targetPanel = document.getElementById(target);
            if (targetPanel) {
                targetPanel.classList.add("active");
            }

            // Re-render graph canvas when tab 2 is opened
            if (target === "tab-graph" && window.graphVisualizerInstance) {
                setTimeout(() => {
                    window.graphVisualizerInstance.initCanvasSize();
                    window.graphVisualizerInstance.fetchGraphData();
                }, 100);
            }

            // Refresh threat feed when tab 3 is opened
            if (target === "tab-threat") {
                fetchThreatFeed();
            }
        });
    });
}

// Load Predefined SIH Scam Scenarios
async function initScenarios() {
    try {
        const res = await fetch("/api/scenarios");
        const data = await res.json();
        currentScenarios = data.scenarios || [];
        renderScenariosList();
        
        // Auto-select Scenario 1 by default
        if (currentScenarios.length > 0) {
            selectScenario(currentScenarios[0]);
        }
    } catch (e) {
        console.error("Failed to load scenarios:", e);
    }
}

function renderScenariosList() {
    const container = document.getElementById("scenarios-list");
    if (!container) return;

    container.innerHTML = currentScenarios.map((s, idx) => `
        <div class="scenario-card ${idx === 0 ? 'active' : ''}" data-id="${s.id}">
            <div class="scen-title">${s.title}</div>
            <div class="scen-subtitle">${s.subtitle}</div>
            <div class="scen-meta">
                <span class="scen-amount">₹${s.amount.toLocaleString()}</span>
                <span class="scen-badge ${s.expected_risk.toLowerCase()}">${s.expected_risk} RISK</span>
            </div>
        </div>
    `).join("");

    container.querySelectorAll(".scenario-card").forEach(card => {
        card.addEventListener("click", () => {
            container.querySelectorAll(".scenario-card").forEach(c => c.classList.remove("active"));
            card.classList.add("active");
            const scen = currentScenarios.find(s => s.id === card.dataset.id);
            if (scen) selectScenario(scen);
        });
    });
}

function selectScenario(scen) {
    document.getElementById("input-recipient").value = scen.recipient_vpa;
    document.getElementById("input-amount").value = scen.amount;
    document.getElementById("input-note").value = scen.note;
    document.getElementById("select-type").value = scen.transaction_type;

    document.getElementById("chk-call-active").checked = scen.call_active || false;
    document.getElementById("chk-screen-share").checked = scen.screen_sharing || false;
    document.getElementById("chk-late-night").checked = (scen.hour_of_day === 2);

    // Run passive background analysis for live diagnostics preview
    triggerAnalysis(false);
}

// Bind Phone Payment Form
function bindFormEvents() {
    const form = document.getElementById("payment-form");
    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            triggerAnalysis(true); // true = open modal on risk
        });
    }

    // QR Scan Simulation button
    const qrBtn = document.getElementById("btn-qr-scan");
    if (qrBtn) {
        qrBtn.addEventListener("click", () => {
            document.getElementById("input-recipient").value = "refund-collector-99@paytm";
            document.getElementById("input-amount").value = "8500";
            document.getElementById("input-note").value = "Scan QR to receive ₹8,500 OLX payment";
            document.getElementById("select-type").value = "COLLECT_REQUEST";
            triggerAnalysis(true);
        });
    }

    // Modifiers triggers
    ["chk-call-active", "chk-screen-share", "chk-late-night", "chk-new-device"].forEach(id => {
        const chk = document.getElementById(id);
        if (chk) {
            chk.addEventListener("change", () => triggerAnalysis(false));
        }
    });
}

// Main Transaction Evaluation Trigger
async function triggerAnalysis(openModalIfRisk = false) {
    const recipient = document.getElementById("input-recipient").value.trim();
    const amount = parseFloat(document.getElementById("input-amount").value) || 0;
    const note = document.getElementById("input-note").value.trim();
    const type = document.getElementById("select-type").value;

    const callActive = document.getElementById("chk-call-active").checked;
    const screenShare = document.getElementById("chk-screen-share").checked;
    const lateNight = document.getElementById("chk-late-night").checked;
    const newDevice = document.getElementById("chk-new-device").checked;

    if (!recipient || amount <= 0) return;

    try {
        const payload = {
            sender_vpa: "gayatri@okaxis",
            recipient_vpa: recipient,
            amount: amount,
            note: note,
            transaction_type: type,
            sender_baseline_avg: 1200.0,
            hour_of_day: lateNight ? 2 : 14,
            call_active: callActive,
            screen_sharing: screenShare,
            is_new_device: newDevice,
            geo_distance_km: callActive ? 1200.0 : 15.0
        };

        const res = await fetch("/api/analyze-transaction", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        currentAnalysisResult = data;

        // Update Diagnostics Panel
        updateDiagnosticsUI(data);

        // Update Header Latency Metric
        const hdrLatency = document.getElementById("hdr-latency");
        if (hdrLatency) hdrLatency.textContent = `${data.latency_ms} ms`;

        // If user explicitly pressed "Proceed to Pay"
        if (openModalIfRisk) {
            if (data.risk_score >= 30) {
                playAlertTone("critical");
                openPrePinInterceptionModal(data);
            } else {
                // Safe legitimate transaction -> Go directly to PIN Pad
                playAlertTone("click");
                openPinPadModal(recipient, amount);
            }
        }

    } catch (e) {
        console.error("Analysis API failed:", e);
    }
}

// Update Diagnostics UI Panel
function updateDiagnosticsUI(data) {
    const placeholder = document.getElementById("diagnostics-placeholder");
    const content = document.getElementById("diagnostics-content");
    if (placeholder) placeholder.classList.add("hidden");
    if (content) content.classList.remove("hidden");

    // Score Meter
    const scoreNum = document.getElementById("diag-score");
    const ringBar = document.getElementById("score-ring-bar");
    const tierBadge = document.getElementById("diag-tier-badge");
    const latencyVal = document.getElementById("diag-latency");
    const actionVal = document.getElementById("diag-action");

    if (scoreNum) scoreNum.textContent = data.risk_score;
    if (latencyVal) latencyVal.textContent = `${data.latency_ms} ms`;
    if (actionVal) actionVal.textContent = data.action_code.replace(/_/g, " ");

    // Radial Progress: circumference = 2 * PI * 42 ≈ 264
    const offset = 264 - (264 * data.risk_score) / 100;
    if (ringBar) {
        ringBar.style.strokeDashoffset = offset;
        if (data.risk_score >= 75) ringBar.style.stroke = "#ef4444";
        else if (data.risk_score >= 50) ringBar.style.stroke = "#f97316";
        else if (data.risk_score >= 30) ringBar.style.stroke = "#eab308";
        else ringBar.style.stroke = "#10b981";
    }

    if (tierBadge) {
        tierBadge.className = `tier-badge ${data.risk_tier.toLowerCase()}`;
        tierBadge.textContent = `${data.risk_tier} RISK (${data.risk_score}/100)`;
    }

    // Engine Sub-Bars
    const vpaScore = data.engine_breakdowns.vpa_analyzer.risk_score || 0;
    const socScore = data.engine_breakdowns.social_engineering.social_risk_score || 0;
    const grpScore = data.engine_breakdowns.mule_graph.graph_risk_score || 0;
    const mlScore = data.engine_breakdowns.ml_ensemble.ml_risk_score || 0;

    setBar("score-vpa", "bar-vpa", vpaScore);
    setBar("score-social", "bar-social", socScore);
    setBar("score-graph", "bar-graph", grpScore);
    setBar("score-ml", "bar-ml", mlScore);

    // Tokenized Info
    const tokenInfo = data.tokenized_info;
    const maskedEl = document.getElementById("diag-masked-vpa");
    const tokenEl = document.getElementById("diag-token-id");
    const badgeContainer = document.getElementById("diag-badge-container");

    if (maskedEl) maskedEl.textContent = tokenInfo.masked_vpa;
    if (tokenEl) tokenEl.textContent = tokenInfo.token_id;
    if (badgeContainer) {
        badgeContainer.innerHTML = `<span class="security-badge ${data.risk_score >= 50 ? 'red' : 'green'}">${tokenInfo.badge_label}</span>`;
    }
}

function setBar(textId, barId, score) {
    const textEl = document.getElementById(textId);
    const barEl = document.getElementById(barId);
    if (textEl) textEl.textContent = `${score}%`;
    if (barEl) {
        barEl.style.width = `${score}%`;
        barEl.className = `progress-fill ${score >= 75 ? 'red' : score >= 50 ? 'orange' : score >= 30 ? 'yellow' : 'green'}`;
    }
}

// ==================== MODAL CONTROLS ====================
function openPrePinInterceptionModal(data) {
    const modal = document.getElementById("prepin-modal");
    if (!modal) return;

    // Reset challenge state
    isCoercedSelection = null;
    document.getElementById("btn-coerced-no")?.classList.remove("active");
    document.getElementById("input-math-answer").value = "";
    document.getElementById("chk-modal-disclaimer").checked = false;

    // Populate data
    document.getElementById("modal-risk-title").textContent = `${data.risk_tier} FRAUD INTERCEPTION (${data.risk_score}/100)`;
    document.getElementById("modal-latency-val").textContent = `${data.latency_ms} ms (Sub-200ms Target Passed)`;
    document.getElementById("modal-masked-vpa").textContent = data.tokenized_info.masked_vpa;
    document.getElementById("modal-security-badge").textContent = data.tokenized_info.badge_label;

    // Multi-Lingual Regional Voice Script
    currentVoiceLang = "en";
    updateVoiceScript(data);

    // Explainable AI (XAI) Factor Bars
    const xai = data.xai_explanation;
    const factorsContainer = document.getElementById("modal-xai-factors");
    if (factorsContainer && xai.attributions) {
        factorsContainer.innerHTML = xai.attributions.map(attr => `
            <div class="xai-factor-row">
                <div class="xai-factor-header">
                    <span>${attr.factor}</span>
                    <strong style="color: #38bdf8;">+${attr.weight_percent}% Attribution</strong>
                </div>
                <div class="progress-track">
                    <div class="progress-fill ${attr.weight_percent > 30 ? 'red' : 'orange'}" style="width: ${attr.weight_percent}%;"></div>
                </div>
            </div>
        `).join("");
    }

    // Evidence Bullet Points
    const evidenceUl = document.getElementById("modal-evidence-ul");
    if (evidenceUl && xai.key_evidence_reasons) {
        evidenceUl.innerHTML = xai.key_evidence_reasons.map(r => `<li>${r}</li>`).join("");
    }

    // Action Advisory
    const advEl = document.getElementById("modal-action-advisory");
    if (advEl) advEl.textContent = xai.action_recommendation;

    // Step-Up Anti-Coercion Challenge
    const stepUp = data.step_up_challenge;
    const stepUpBox = document.getElementById("step-up-challenge-box");
    if (stepUp && stepUp.requires_challenge) {
        stepUpBox.classList.remove("hidden");
        document.getElementById("modal-stepup-statement").textContent = stepUp.awareness_statement;
        document.getElementById("modal-coercion-q").textContent = stepUp.confirmation_question;
        document.getElementById("modal-math-q").textContent = stepUp.math_question;
        document.getElementById("modal-disclaimer-text").textContent = stepUp.required_checkbox;
    } else {
        stepUpBox.classList.add("hidden");
    }

    modal.classList.remove("hidden");
}

function updateVoiceScript(data) {
    const xai = data.xai_explanation;
    const voiceTextEl = document.getElementById("modal-voice-text");
    if (voiceTextEl && xai.voice_alerts) {
        voiceTextEl.textContent = `"${xai.voice_alerts[currentVoiceLang] || xai.voice_alerts['en']}"`;
    }
}

// Web Speech API Voice Alert Player
function playVoiceAlert() {
    if (!currentAnalysisResult) return;
    const xai = currentAnalysisResult.xai_explanation;
    const script = xai.voice_alerts[currentVoiceLang] || xai.voice_alerts["en"];

    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel(); // Stop any ongoing speech
        const utterance = new SpeechSynthesisUtterance(script);

        // Language tag mapping
        if (currentVoiceLang === "hi") utterance.lang = "hi-IN";
        else if (currentVoiceLang === "mr") utterance.lang = "mr-IN";
        else if (currentVoiceLang === "ta") utterance.lang = "ta-IN";
        else utterance.lang = "en-IN";

        utterance.rate = 0.95;
        utterance.pitch = 1.0;

        const waves = document.getElementById("voice-waves");
        utterance.onstart = () => {
            isSpeaking = true;
            if (waves) waves.classList.add("playing");
        };
        utterance.onend = () => {
            isSpeaking = false;
            if (waves) waves.classList.remove("playing");
        };
        utterance.onerror = () => {
            isSpeaking = false;
            if (waves) waves.classList.remove("playing");
        };

        window.speechSynthesis.speak(utterance);
    } else {
        alert("Web Speech API not supported on this browser.");
    }
}

function bindModalEvents() {
    // Close modal
    document.getElementById("modal-close-btn")?.addEventListener("click", () => {
        document.getElementById("prepin-modal")?.classList.add("hidden");
        window.speechSynthesis?.cancel();
    });

    document.getElementById("btn-modal-cancel")?.addEventListener("click", () => {
        document.getElementById("prepin-modal")?.classList.add("hidden");
        window.speechSynthesis?.cancel();
        alert("✅ Transaction canceled safely. No money was deducted.");
    });

    // Language buttons
    document.querySelectorAll(".lang-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".lang-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentVoiceLang = btn.dataset.lang;
            if (currentAnalysisResult) {
                updateVoiceScript(currentAnalysisResult);
            }
        });
    });

    // Play Voice Alert
    document.getElementById("btn-play-voice")?.addEventListener("click", playVoiceAlert);

    // Coercion selection buttons
    const btnYes = document.getElementById("btn-coerced-yes");
    const btnNo = document.getElementById("btn-coerced-no");

    if (btnYes) {
        btnYes.addEventListener("click", () => {
            // User admitted to being on a scam call -> Trigger Emergency Block Modal
            document.getElementById("prepin-modal")?.classList.add("hidden");
            window.speechSynthesis?.cancel();
            document.getElementById("blocked-modal")?.classList.remove("hidden");
        });
    }

    if (btnNo) {
        btnNo.addEventListener("click", () => {
            isCoercedSelection = false;
            btnNo.classList.add("active");
        });
    }

    // Dismiss Blocked Modal
    document.getElementById("btn-blocked-dismiss")?.addEventListener("click", () => {
        document.getElementById("blocked-modal")?.classList.add("hidden");
    });

    // Proceed to PIN Pad Button (Verification check)
    document.getElementById("btn-modal-proceed-pin")?.addEventListener("click", async () => {
        if (!currentAnalysisResult) return;
        const stepUp = currentAnalysisResult.step_up_challenge;

        if (stepUp && stepUp.requires_challenge) {
            const mathAns = document.getElementById("input-math-answer").value.trim();
            const disclaimer = document.getElementById("chk-modal-disclaimer").checked;

            if (isCoercedSelection === null) {
                alert("⚠️ Please answer the coercion check: Are you on a call with police/bank?");
                return;
            }

            if (!mathAns) {
                alert("⚠️ Please solve the human verification math question.");
                return;
            }

            if (!disclaimer) {
                alert("⚠️ You must acknowledge the security advisory checkbox.");
                return;
            }

            // Verify with backend
            const verifyRes = await fetch("/api/verify-step-up", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    challenge_type: stepUp.challenge_type,
                    user_math_answer: mathAns,
                    expected_math_answer: stepUp.expected_math_answer,
                    acknowledged_checkbox: disclaimer,
                    is_coerced_answer: isCoercedSelection === true
                })
            });

            const verifyData = await verifyRes.json();
            if (!verifyData.success) {
                alert(`❌ ${verifyData.message}`);
                return;
            }
        }

        // Proceed to PIN Pad
        document.getElementById("prepin-modal")?.classList.add("hidden");
        window.speechSynthesis?.cancel();
        openPinPadModal(
            currentAnalysisResult.recipient_vpa,
            parseFloat(document.getElementById("input-amount").value) || 0
        );
    });
}

// ==================== PIN PAD SIMULATION ====================
function openPinPadModal(recipient, amount) {
    currentEnteredPin = "";
    updatePinDots();

    document.getElementById("pin-payee-display").textContent = `Gayatri ➔ ${recipient}`;
    document.getElementById("pin-amount-display").textContent = `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    document.getElementById("pinpad-modal")?.classList.remove("hidden");
}

function bindPinpadEvents() {
    document.querySelectorAll(".keypad-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const key = btn.dataset.key;
            if (key !== undefined) {
                if (currentEnteredPin.length < 4) {
                    playAlertTone("click");
                    currentEnteredPin += key;
                    updatePinDots();
                }
            }
        });
    });

    document.getElementById("btn-keypad-clear")?.addEventListener("click", () => {
        playAlertTone("click");
        currentEnteredPin = "";
        updatePinDots();
    });

    document.getElementById("btn-pinpad-cancel")?.addEventListener("click", () => {
        document.getElementById("pinpad-modal")?.classList.add("hidden");
    });

    document.getElementById("btn-keypad-submit")?.addEventListener("click", () => {
        if (currentEnteredPin.length === 4) {
            playAlertTone("success");
            document.getElementById("pinpad-modal")?.classList.add("hidden");
            alert(`🎉 Payment of ${document.getElementById("pin-amount-display").textContent} AUTHORIZED via UPI PIN.`);
            fetchThreatFeed(); // update logs
        } else {
            alert("Please enter a 4-digit UPI PIN.");
        }
    });
}

function updatePinDots() {
    for (let i = 1; i <= 4; i++) {
        const dot = document.getElementById(`dot-${i}`);
        if (dot) {
            if (i <= currentEnteredPin.length) {
                dot.classList.add("filled");
            } else {
                dot.classList.remove("filled");
            }
        }
    }
}

// ==================== TAB 3: THREAT FEED & REPORT VPA ====================
async function fetchThreatFeed() {
    try {
        const res = await fetch("/api/threat-feed");
        const data = await res.json();
        renderAuditTable(data.audit_feed || []);
        
        // Update Blacklist tag list
        const tagsContainer = document.getElementById("blacklist-tags-list");
        if (tagsContainer && window.graphVisualizerInstance) {
            const blCount = document.getElementById("stat-zero-days");
            if (blCount) blCount.textContent = (data.audit_feed || []).filter(a => a.risk_score >= 75).length + 142;
        }
    } catch (e) {
        console.error("Threat feed fetch failed:", e);
    }
}

function renderAuditTable(feed) {
    const tbody = document.getElementById("audit-table-body");
    if (!tbody) return;

    if (feed.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#64748b; padding:20px;">No transactions processed yet. Run a simulation above!</td></tr>`;
        return;
    }

    tbody.innerHTML = feed.map(item => `
        <tr>
            <td class="mono" style="color: #38bdf8;">${item.id}</td>
            <td>${item.time}</td>
            <td class="mono">${item.recipient_masked}</td>
            <td class="mono">₹${item.amount.toLocaleString()}</td>
            <td><span class="tier-badge ${item.risk_tier.toLowerCase()}">${item.risk_tier} (${item.risk_score})</span></td>
            <td class="mono" style="color: #34d399;">${item.latency_ms} ms</td>
            <td>${item.scam_category}</td>
        </tr>
    `).join("");
}

function bindThreatFeedEvents() {
    document.getElementById("btn-refresh-feed")?.addEventListener("click", fetchThreatFeed);

    const reportForm = document.getElementById("report-vpa-form");
    if (reportForm) {
        reportForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const vpa = document.getElementById("input-report-vpa").value.trim();
            const reason = document.getElementById("input-report-reason").value;

            if (!vpa) return;

            try {
                const res = await fetch("/api/report-vpa", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ vpa: vpa, reason: reason })
                });
                const data = await res.json();
                alert(`🚨 SUCCESS: ${data.message}`);
                
                // Add tag
                const tags = document.getElementById("blacklist-tags-list");
                if (tags) {
                    const newTag = document.createElement("span");
                    newTag.className = "bl-tag";
                    newTag.textContent = vpa;
                    tags.appendChild(newTag);
                }

                document.getElementById("input-report-vpa").value = "";
                fetchThreatFeed();
            } catch (err) {
                alert("Failed to report VPA: " + err);
            }
        });
    }
}
