"""ByteShield - Module 3: Graph-Based Fraud Ring & Mule Network Engine
Models dynamic transaction graphs with NetworkX to detect Zero-Day accounts,
fan-out mule clusters, shared device rings, and money-laundering chains.
"""

import networkx as nx
import time
from typing import Dict, Any, List, Optional, Set, Tuple


class MuleGraphEngine:
    """Graph Neural & NetworkX analysis engine for UPI transaction rings."""

    def __init__(self):
        self.graph = nx.DiGraph()
        self.device_map: Dict[str, Set[str]] = {}
        self.account_metadata: Dict[str, Dict[str, Any]] = {}
        self.blacklist_vpas: Set[str] = set()
        self._seed_default_graph()

    def _seed_default_graph(self):
        """Seed the graph with representative nodes and fraud rings."""
        # 1. Legitimate Merchants & Users
        self.add_or_update_account("gayatri@okaxis", name="Gayatri (Sender/User)", account_age_hours=8760, is_verified=True, kyc_tier="FULL", risk_baseline=5)
        self.add_or_update_account("swiggy@icici", name="Swiggy Official", account_age_hours=26280, is_verified=True, kyc_tier="MERCHANT", risk_baseline=0)
        self.add_or_update_account("tatapower@icici", name="Tata Power Mumbai", account_age_hours=35040, is_verified=True, kyc_tier="MERCHANT", risk_baseline=0)
        self.add_or_update_account("rohit_friend@okhdfcbank", name="Rohit Sharma (Friend)", account_age_hours=4380, is_verified=True, kyc_tier="FULL", risk_baseline=5)

        # 2. Digital Arrest Scam Ring
        self.add_or_update_account(
            "cbi-investigation-cell@ybl",
            name="Fake CBI Investigation Cell",
            account_age_hours=2.5,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=95,
            device_id="DEV-JAM-9821"
        )
        self.add_or_update_account(
            "police-clearance-desk@okaxis",
            name="Police Clearance Desk (Spoof)",
            account_age_hours=4.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=92,
            device_id="DEV-JAM-9821"
        )
        self.add_or_update_account(
            "mule_layer1_arun@paytm",
            name="Arun Kumar (Mule 1)",
            account_age_hours=12.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=85,
            device_id="DEV-MULE-101"
        )
        self.add_or_update_account(
            "mule_layer1_vikas@okicici",
            name="Vikas Singh (Mule 2)",
            account_age_hours=14.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=85,
            device_id="DEV-MULE-102"
        )
        self.add_or_update_account(
            "mule_layer2_subhash@ybl",
            name="Subhash Pal (Mule 3 - Consolidator)",
            account_age_hours=18.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=88,
            device_id="DEV-MULE-201"
        )
        self.add_or_update_account(
            "cashout_p2p_crypto@axl",
            name="Offshore P2P Cashout Terminal",
            account_age_hours=24.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=98,
            device_id="DEV-CASHOUT-99"
        )

        # Connect the scam ring edges
        self.record_transaction("cbi-investigation-cell@ybl", "mule_layer1_arun@paytm", 45000, "Rapid Dispersal Layer 1")
        self.record_transaction("cbi-investigation-cell@ybl", "mule_layer1_vikas@okicici", 48000, "Rapid Dispersal Layer 1")
        self.record_transaction("mule_layer1_arun@paytm", "mule_layer2_subhash@ybl", 42000, "Mule Consolidation")
        self.record_transaction("mule_layer1_vikas@okicici", "mule_layer2_subhash@ybl", 46000, "Mule Consolidation")
        self.record_transaction("mule_layer2_subhash@ybl", "cashout_p2p_crypto@axl", 85000, "Crypto Off-ramp Cashout")

        # 3. Fake SBI Customer Care Spoof Ring
        self.add_or_update_account(
            "sbi-customercare-support@ybl",
            name="Fake SBI Support Desk",
            account_age_hours=3.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=90,
            device_id="DEV-NUH-5542"
        )
        self.add_or_update_account(
            "sbi-helpdesk-agent@okaxis",
            name="Fake SBI Helpdesk Agent",
            account_age_hours=5.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=88,
            device_id="DEV-NUH-5542"
        )
        self.add_or_update_account(
            "refund-collector-99@paytm",
            name="Mule Pool Collector",
            account_age_hours=10.0,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=86,
            device_id="DEV-MULE-303"
        )
        self.record_transaction("sbi-customercare-support@ybl", "refund-collector-99@paytm", 24999, "Victim Fund Exfiltration")
        self.record_transaction("sbi-helpdesk-agent@okaxis", "refund-collector-99@paytm", 32000, "Victim Fund Exfiltration")

        # 4. Zero-Day Task Scam Account
        self.add_or_update_account(
            "earn-daily-bonus99@okicici",
            name="Telegram VIP Task Pool",
            account_age_hours=1.2,
            is_verified=False,
            kyc_tier="MINIMAL",
            risk_baseline=92,
            device_id="DEV-TASK-883"
        )

        # 5. Legitimate transfers
        self.record_transaction("gayatri@okaxis", "swiggy@icici", 450, "Food Delivery")
        self.record_transaction("gayatri@okaxis", "tatapower@icici", 1850, "Electricity Bill")
        self.record_transaction("gayatri@okaxis", "rohit_friend@okhdfcbank", 500, "Split lunch")

        # Blacklisted known bad VPAs
        self.blacklist_vpas.add("cbi-investigation-cell@ybl")
        self.blacklist_vpas.add("cashout_p2p_crypto@axl")
        self.blacklist_vpas.add("sbi-customercare-support@ybl")

    def add_or_update_account(
        self,
        vpa: str,
        name: str,
        account_age_hours: float,
        is_verified: bool = False,
        kyc_tier: str = "MINIMAL",
        risk_baseline: int = 0,
        device_id: Optional[str] = None
    ):
        """Register or update an account node in the graph."""
        vpa_clean = vpa.strip().lower()
        self.account_metadata[vpa_clean] = {
            "vpa": vpa_clean,
            "name": name,
            "account_age_hours": account_age_hours,
            "is_verified": is_verified,
            "kyc_tier": kyc_tier,
            "risk_baseline": risk_baseline,
            "device_id": device_id,
            "created_at": time.time() - (account_age_hours * 3600)
        }
        
        if not self.graph.has_node(vpa_clean):
            self.graph.add_node(
                vpa_clean,
                name=name,
                account_age_hours=account_age_hours,
                is_verified=is_verified,
                risk=risk_baseline,
                device_id=device_id
            )
        else:
            self.graph.nodes[vpa_clean]["account_age_hours"] = account_age_hours
            self.graph.nodes[vpa_clean]["risk"] = risk_baseline
            if device_id:
                self.graph.nodes[vpa_clean]["device_id"] = device_id

        if device_id:
            if device_id not in self.device_map:
                self.device_map[device_id] = set()
            self.device_map[device_id].add(vpa_clean)

    def record_transaction(self, sender_vpa: str, receiver_vpa: str, amount: float, remark: str = ""):
        """Add or update an edge between sender and receiver."""
        s, r = sender_vpa.strip().lower(), receiver_vpa.strip().lower()
        if not self.graph.has_node(s):
            self.add_or_update_account(s, name=s, account_age_hours=720, is_verified=False)
        if not self.graph.has_node(r):
            self.add_or_update_account(r, name=r, account_age_hours=1.0, is_verified=False)

        if self.graph.has_edge(s, r):
            self.graph[s][r]["amount"] += amount
            self.graph[s][r]["count"] += 1
            self.graph[s][r]["last_timestamp"] = time.time()
        else:
            self.graph.add_edge(
                s, r,
                amount=amount,
                count=1,
                remark=remark,
                last_timestamp=time.time()
            )

    def evaluate_graph_risk(self, sender_vpa: str, receiver_vpa: str, amount: float) -> Dict[str, Any]:
        """
        Analyze network topology, mule ring proximity, shared devices, and Zero-Day account indicators.
        """
        s = sender_vpa.strip().lower()
        r = receiver_vpa.strip().lower()
        reasons: List[str] = []
        graph_risk = 0
        is_zero_day = False
        is_mule_ring_member = False
        is_blacklisted = r in self.blacklist_vpas

        # 1. Blacklist check
        if is_blacklisted:
            graph_risk = 100
            reasons.append("🚨 Threat Intelligence Blacklist: Recipient UPI ID is actively blacklisted in National Cyber Crime Registry.")

        # 2. Account Age / Zero-Day Assessment
        meta = self.account_metadata.get(r)
        if meta:
            age_hours = meta.get("account_age_hours", 24)
            if age_hours < 6.0:
                is_zero_day = True
                graph_risk = max(graph_risk, 85)
                reasons.append(f"Zero-Day Scam Account: Recipient VPA was created only {age_hours:.1f} hours ago with no prior legitimate history.")
            elif age_hours < 24.0:
                is_zero_day = True
                graph_risk = max(graph_risk, 60)
                reasons.append(f"Fresh Account Risk: Recipient VPA is less than {int(age_hours)} hours old.")
        else:
            is_zero_day = True
            graph_risk = max(graph_risk, 45)
            reasons.append("Unseen New VPA: Recipient has no prior transaction history in national graph database.")

        # 3. Fan-out / Mule Dispersal Topology Detection
        if self.graph.has_node(r):
            out_degree = self.graph.out_degree(r)
            out_edges = list(self.graph.out_edges(r, data=True))
            
            if out_degree >= 2:
                total_out = sum(data.get("amount", 0) for _, _, data in out_edges)
                is_mule_ring_member = True
                graph_risk = max(graph_risk, 90)
                reasons.append(f"Graph Mule Detection: Recipient exhibits fan-out dispersal topology (splitting ₹{total_out:,.0f} across {out_degree} downstream mule accounts).")

            for _, target_node in self.graph.out_edges(r):
                if target_node in self.blacklist_vpas or "cashout" in target_node or "crypto" in target_node:
                    is_mule_ring_member = True
                    graph_risk = max(graph_risk, 92)
                    reasons.append(f"Money Laundering Chain: Recipient routes directly to high-risk cashout node '{target_node}'.")
                    break

        # 4. Shared Device Fingerprint Ring Check
        if meta and meta.get("device_id"):
            dev_id = meta["device_id"]
            associated_vpas = self.device_map.get(dev_id, set())
            if len(associated_vpas) > 1:
                graph_risk = max(graph_risk, 88)
                is_mule_ring_member = True
                other_vpas = [v for v in associated_vpas if v != r][:2]
                reasons.append(f"Shared Device Fraud Ring: Device '{dev_id}' is shared across multiple suspicious accounts ({', '.join(other_vpas)}).")

        graph_risk = min(100, max(0, graph_risk))

        return {
            "graph_risk_score": graph_risk,
            "is_blacklisted": is_blacklisted,
            "is_zero_day": is_zero_day,
            "is_mule_ring_member": is_mule_ring_member,
            "account_age_hours": meta.get("account_age_hours", 0) if meta else 0.5,
            "device_id": meta.get("device_id", "UNKNOWN") if meta else "UNKNOWN",
            "graph_reasons": reasons if reasons else ["Node topology normal; no mule dispersal patterns."]
        }

    def get_full_graph_visualization_data(self) -> Dict[str, Any]:
        """Return nodes and links formatted for the interactive visualizer."""
        nodes = []
        links = []

        for node_id in self.graph.nodes:
            meta = self.account_metadata.get(node_id, {})
            in_deg = self.graph.in_degree(node_id)
            out_deg = self.graph.out_degree(node_id)
            is_blacklisted = node_id in self.blacklist_vpas
            
            if is_blacklisted or "cbi" in node_id or "sbi-customercare" in node_id or "police" in node_id:
                category = "scammer_hub"
                color = "#dc2626"
                size = 18
            elif "cashout" in node_id or "crypto" in node_id:
                category = "cashout_node"
                color = "#7c3aed"
                size = 20
            elif "mule" in node_id or "collector" in node_id:
                category = "mule_account"
                color = "#ea580c"
                size = 14
            elif "swiggy" in node_id or "tatapower" in node_id or meta.get("is_verified", False):
                category = "verified_merchant"
                color = "#059669"
                size = 16
            else:
                category = "user"
                color = "#2563eb"
                size = 12

            nodes.append({
                "id": node_id,
                "label": meta.get("name", node_id),
                "category": category,
                "color": color,
                "size": size,
                "account_age_hours": meta.get("account_age_hours", 24),
                "in_degree": in_deg,
                "out_degree": out_deg,
                "device_id": meta.get("device_id", "N/A"),
                "is_blacklisted": is_blacklisted
            })

        for u, v, data in self.graph.edges(data=True):
            links.append({
                "source": u,
                "target": v,
                "amount": data.get("amount", 0),
                "count": data.get("count", 1),
                "remark": data.get("remark", "")
            })

        return {
            "nodes": nodes,
            "links": links,
            "total_nodes": len(nodes),
            "total_edges": len(links),
            "blacklisted_count": len(self.blacklist_vpas)
        }

    def blacklist_vpa(self, vpa: str, reason: str = "User Reported / Cyber Crime Feed"):
        """Add a VPA to real-time blacklist."""
        vpa_clean = vpa.strip().lower()
        self.blacklist_vpas.add(vpa_clean)
        if vpa_clean in self.account_metadata:
            self.account_metadata[vpa_clean]["risk_baseline"] = 100
        if self.graph.has_node(vpa_clean):
            self.graph.nodes[vpa_clean]["risk"] = 100


mule_graph_instance = MuleGraphEngine()
